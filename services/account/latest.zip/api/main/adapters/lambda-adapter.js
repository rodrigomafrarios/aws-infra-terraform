"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaAdapt = void 0;
const apiGateway_1 = require("@/libs/apiGateway");
const lambdaAdapt = (controller) => {
    return async (data) => {
        const httpRequest = {
            body: data
        };
        const httpResponse = await controller.handle(httpRequest);
        return apiGateway_1.formatJSONResponse(httpResponse);
    };
};
exports.lambdaAdapt = lambdaAdapt;
//# sourceMappingURL=lambda-adapter.js.map