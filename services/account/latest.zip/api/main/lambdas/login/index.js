"use strict";
/* eslint no-template-curly-in-string: "off" */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const schema_1 = __importDefault(require("@/main/lambdas/login/schema"));
const handlerResolver_1 = require("@/libs/handlerResolver");
exports.default = {
    role: '${ssm:${self:custom.stage}-list-accounts-iam-role}',
    environment: {
        DYNAMODB_ACCOUNTS: '${ssm:${self:custom.stage}-dynamodb-accounts-table}',
        JWT_SECRET: '${ssm:${self:custom.stage}-jwt-secret}'
    },
    handler: `${handlerResolver_1.handlerPath(__dirname)}/main.handler`,
    events: [
        {
            http: {
                method: 'post',
                path: 'login',
                request: {
                    schema: {
                        'application/json': schema_1.default
                    }
                }
            }
        }
    ]
};
//# sourceMappingURL=index.js.map