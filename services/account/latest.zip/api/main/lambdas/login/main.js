"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
require("module-alias/register");
require("source-map-support/register");
const lambda_1 = require("@/libs/lambda");
const login_controller_factory_1 = require("../../factories/controllers/login/login-controller-factory");
const lambda_adapter_1 = require("../../adapters/lambda-adapter");
const login = async (event) => {
    const { body } = event;
    const controller = login_controller_factory_1.makeLoginController();
    const httpResponse = lambda_adapter_1.lambdaAdapt(controller)({
        ...body
    });
    return httpResponse;
};
exports.handler = lambda_1.middyfy(login);
//# sourceMappingURL=main.js.map