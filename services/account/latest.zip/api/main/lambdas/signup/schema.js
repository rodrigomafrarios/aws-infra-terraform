"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    type: 'object',
    properties: {
        email: { type: 'string' },
        password: { type: 'string' },
        name: { type: 'string' }
    },
    required: ['email', 'password', 'name']
};
//# sourceMappingURL=schema.js.map