"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signUp = exports.login = void 0;
var login_1 = require("./login");
Object.defineProperty(exports, "login", { enumerable: true, get: function () { return __importDefault(login_1).default; } });
var signup_1 = require("./signup");
Object.defineProperty(exports, "signUp", { enumerable: true, get: function () { return __importDefault(signup_1).default; } });
//# sourceMappingURL=index.js.map