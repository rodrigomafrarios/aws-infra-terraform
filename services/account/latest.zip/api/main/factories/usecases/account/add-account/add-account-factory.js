"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeAddAccount = void 0;
const db_add_account_1 = require("@/data/usecases/account/add-account/db-add-account");
const aws_config_factory_1 = require("@/infra/aws/factories/aws-config-factory");
const bcrypt_adapter_1 = require("@/infra/criptography/bcrypt-adapter/bcrypt-adapter");
const account_dynamodb_repository_1 = require("@/infra/db/dynamodb/account/account-dynamodb-repository");
const makeAddAccount = () => {
    const salt = 12;
    const bcryptAdapter = new bcrypt_adapter_1.BcryptAdapter(salt);
    const dynamoClient = aws_config_factory_1.DynamoDBClientFactory({ apiVersion: '2012-08-10' });
    const accountRepository = new account_dynamodb_repository_1.AccountDynamoDbRepository(dynamoClient);
    return new db_add_account_1.DbAddAccount(accountRepository, accountRepository, bcryptAdapter);
};
exports.makeAddAccount = makeAddAccount;
//# sourceMappingURL=add-account-factory.js.map