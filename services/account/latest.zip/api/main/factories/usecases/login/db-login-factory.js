"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeDbLogin = void 0;
const db_login_1 = require("@/data/usecases/login/db-login");
const account_dynamodb_repository_1 = require("@/infra/db/dynamodb/account/account-dynamodb-repository");
const bcrypt_adapter_1 = require("@/infra/criptography/bcrypt-adapter/bcrypt-adapter");
const jwt_adapter_1 = require("@/infra/criptography/jwt/jwt-adapter");
const aws_config_factory_1 = require("@/infra/aws/factories/aws-config-factory");
const makeDbLogin = () => {
    const salt = 12;
    const bcryptAdapter = new bcrypt_adapter_1.BcryptAdapter(salt);
    const jwtAdapter = new jwt_adapter_1.JwtAdapter(process.env.JWT_SECRET);
    const dynamoClient = aws_config_factory_1.DynamoDBClientFactory({ apiVersion: '2012-08-10' });
    const accountDynamoDbRepository = new account_dynamodb_repository_1.AccountDynamoDbRepository(dynamoClient);
    return new db_login_1.DbLogin(accountDynamoDbRepository, bcryptAdapter, jwtAdapter, accountDynamoDbRepository);
};
exports.makeDbLogin = makeDbLogin;
//# sourceMappingURL=db-login-factory.js.map