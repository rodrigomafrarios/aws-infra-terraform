"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeLoginController = void 0;
const login_controller_1 = require("@/presentation/controllers/login/login-controller");
const db_login_factory_1 = require("../../../factories/usecases/login/db-login-factory");
const login_validation_factory_1 = require("./login-validation-factory");
const makeLoginController = () => {
    const controller = new login_controller_1.LoginController(db_login_factory_1.makeDbLogin(), login_validation_factory_1.makeLoginValidation());
    return controller;
};
exports.makeLoginController = makeLoginController;
//# sourceMappingURL=login-controller-factory.js.map