"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeSignUpController = void 0;
const signup_validation_factory_1 = require("./signup-validation-factory");
const signup_controller_1 = require("@/presentation/controllers/signup/signup-controller");
const db_login_factory_1 = require("../../../factories/usecases/login/db-login-factory");
const add_account_factory_1 = require("../../../factories/usecases/account/add-account/add-account-factory");
const makeSignUpController = () => {
    const controller = new signup_controller_1.SignupController(signup_validation_factory_1.makeSignupValidation(), add_account_factory_1.makeAddAccount(), db_login_factory_1.makeDbLogin());
    return controller;
};
exports.makeSignUpController = makeSignUpController;
//# sourceMappingURL=signup-controller-factory.js.map