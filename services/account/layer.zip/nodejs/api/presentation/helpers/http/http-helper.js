"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forbidden = exports.ok = exports.serverError = exports.unauthorized = exports.badRequest = void 0;
const server_error_1 = require("@/presentation/errors/server-error");
const unauthorized_error_1 = require("@/presentation/errors/unauthorized-error");
const badRequest = (error) => {
    return {
        statusCode: 400,
        body: error
    };
};
exports.badRequest = badRequest;
const unauthorized = () => {
    return {
        statusCode: 401,
        body: new unauthorized_error_1.UnauthorizedError()
    };
};
exports.unauthorized = unauthorized;
const serverError = (error) => {
    return {
        statusCode: 500,
        body: new server_error_1.ServerError(error.stack)
    };
};
exports.serverError = serverError;
const ok = (data) => {
    return {
        statusCode: 200,
        body: data
    };
};
exports.ok = ok;
const forbidden = (error) => {
    return {
        statusCode: 403,
        body: error
    };
};
exports.forbidden = forbidden;
//# sourceMappingURL=http-helper.js.map