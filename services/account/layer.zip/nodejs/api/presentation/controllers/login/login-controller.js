"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginController = void 0;
const http_helper_1 = require("@/presentation/helpers/http/http-helper");
class LoginController {
    constructor(login, validator) {
        this.login = login;
        this.validator = validator;
    }
    async handle(httpRequest) {
        try {
            const { body } = httpRequest;
            const error = await this.validator.validate(body);
            if (error) {
                return http_helper_1.badRequest(error);
            }
            const accessToken = await this.login.getToken(body);
            if (!accessToken) {
                return http_helper_1.unauthorized();
            }
            return http_helper_1.ok({ accessToken: accessToken });
        }
        catch (error) {
            return http_helper_1.serverError(error);
        }
    }
}
exports.LoginController = LoginController;
//# sourceMappingURL=login-controller.js.map