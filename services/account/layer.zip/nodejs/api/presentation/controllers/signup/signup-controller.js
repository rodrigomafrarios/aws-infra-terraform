"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignupController = void 0;
const email_in_use_error_1 = require("@/presentation/errors/email-in-use-error");
const http_helper_1 = require("@/presentation/helpers/http/http-helper");
class SignupController {
    constructor(validator, addAccount, login) {
        this.validator = validator;
        this.addAccount = addAccount;
        this.login = login;
    }
    async handle(httpRequest) {
        try {
            const { body } = httpRequest;
            const error = await this.validator.validate(body);
            if (error) {
                return http_helper_1.badRequest(error);
            }
            const { name, email, password } = body;
            const account = await this.addAccount.add({
                name,
                email,
                password
            });
            if (!account) {
                return http_helper_1.forbidden(new email_in_use_error_1.EmailInUseError());
            }
            const accessToken = await this.login.getToken({
                email,
                password
            });
            return http_helper_1.ok({ name, accessToken });
        }
        catch (error) {
            return http_helper_1.serverError(error);
        }
    }
}
exports.SignupController = SignupController;
//# sourceMappingURL=signup-controller.js.map