"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountDynamoDbRepository = void 0;
const uuid_1 = require("uuid");
class AccountDynamoDbRepository {
    constructor(client) {
        this.client = client;
    }
    async loadByEmail(email) {
        const output = await this.client.get({
            TableName: process.env.DYNAMODB_ACCOUNTS,
            Key: {
                email
            }
        }).promise();
        return (output === null || output === void 0 ? void 0 : output.Item) && ({
            id: output.Item.id,
            email: output.Item.email,
            password: output.Item.password,
            name: output.Item.name
        });
    }
    async updateAccessToken(email, token) {
        await this.client.transactWrite({
            TransactItems: [{
                    Update: {
                        TableName: process.env.DYNAMODB_ACCOUNTS,
                        Key: {
                            email
                        },
                        UpdateExpression: 'SET accessToken = :token',
                        ExpressionAttributeValues: {
                            ':token': token
                        }
                    }
                }]
        }).promise();
    }
    async add(addAccountParams) {
        await this.client.transactWrite({
            TransactItems: [{
                    Put: {
                        TableName: process.env.DYNAMODB_ACCOUNTS,
                        Item: {
                            id: uuid_1.v4(),
                            ...addAccountParams
                        }
                    }
                }]
        }).promise();
        return await this.loadByEmail(addAccountParams.email);
    }
}
exports.AccountDynamoDbRepository = AccountDynamoDbRepository;
//# sourceMappingURL=account-dynamodb-repository.js.map