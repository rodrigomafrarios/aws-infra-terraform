"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DbAddAccount = void 0;
class DbAddAccount {
    constructor(addAccountRepository, loadAccountByEmailRepository, hasher) {
        this.addAccountRepository = addAccountRepository;
        this.loadAccountByEmailRepository = loadAccountByEmailRepository;
        this.hasher = hasher;
    }
    async add(accountParams) {
        const account = await this.loadAccountByEmailRepository.loadByEmail(accountParams.email);
        if (!account) {
            const hashedPassword = await this.hasher.hash(accountParams.password);
            const addAccountParams = Object.assign({}, accountParams, { password: hashedPassword });
            const newAccount = await this.addAccountRepository.add(addAccountParams);
            return newAccount;
        }
        return null;
    }
}
exports.DbAddAccount = DbAddAccount;
//# sourceMappingURL=db-add-account.js.map