"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DbLogin = void 0;
class DbLogin {
    constructor(loadAccountByEmailRepository, hashComparer, encrypter, updateAccessTokenRepository) {
        this.loadAccountByEmailRepository = loadAccountByEmailRepository;
        this.hashComparer = hashComparer;
        this.encrypter = encrypter;
        this.updateAccessTokenRepository = updateAccessTokenRepository;
    }
    async getToken(params) {
        const account = await this.loadAccountByEmailRepository.loadByEmail(params.email);
        if (account) {
            const isValid = await this.hashComparer.compare(params.password, account.password);
            if (isValid) {
                const accessToken = await this.encrypter.encrypt(account.id);
                await this.updateAccessTokenRepository.updateAccessToken(account.email, accessToken);
                return accessToken;
            }
        }
        return null;
    }
}
exports.DbLogin = DbLogin;
//# sourceMappingURL=db-login.js.map